-- create database library_system
use library_system;
-- create table user_roll(
-- id int auto_increment primary key,
-- type nvarchar(20))engine InnoDB;

-- create table user(
-- id int auto_increment primary key,
-- name nvarchar(100),
-- type int,
-- age int,
-- id_card nvarchar(20),
-- gender int,
-- create_time datetime,
-- password nvarchar(20),
-- update_time datetime,
-- state int,
-- auditor int,
-- phone_number nvarchar(20),
-- user_name nvarchar(24),
-- class int,
-- grade int,
-- card_num nvarchar(20),
-- foreign key(grade) references grade(id),
-- foreign key(class) references class(id),
-- foreign key(type) references user_roll(id),
-- foreign key(auditor) references user(id))engine InnoDB;

describe user;
describe book_info;


-- create table book_type(
-- id int auto_increment primary key,
-- name nvarchar(30))engine InnoDB;

-- create table book_info(
-- id int auto_increment primary key,
-- state int,
-- type int,
-- name nvarchar(50),
-- isbn nvarchar(20),
-- create_time datetime,
-- publish_time datetime,
-- author nvarchar(20),
-- updator int,
-- foreign key(type) references book_type(id),
-- foreign key(updator) references user(id))engine InnoDB;

-- create table class(
-- id int auto_increment primary key,
-- name nvarchar(20),
-- year int,
-- state int,
-- grade int,
-- foreign key(grade) references grade(id))engine InnoDB;

-- create table grade(
-- id int auto_increment primary key,
-- name int)engine InnoDB;

-- create table user_application(
-- id int auto_increment primary key,
-- user_name nvarchar(100),
-- name nvarchar (100),
-- age int,
-- id_card nvarchar(20),
-- gender int,
-- create_time datetime,
-- password nvarchar(20),
-- update_time datetime,
-- state int,
-- auditor int,
-- phone_number nvarchar(20),
-- class int,
-- grade int,
-- card_num nvarchar(20),
-- type int,
-- foreign key(type) references user_roll(id),
-- foreign key(grade) references grade(id),
-- foreign key(class) references class(id))engine InnoDB;

-- create table borrow_book(
-- id int auto_increment primary key,
-- book_info_id int,
-- user_id int,
-- start_time datetime,
-- deadline datetime,
-- state int,
-- add_time datetime,
-- foreign key(book_info_id) references book_info(id),
-- foreign key(user_id) references book_info(id))engine InnoDB;

-- create table overtime_lost(
-- id int auto_increment primary key,
-- borrow_book_id int,
-- state int,
-- type int,
-- foreign key(borrow_book_id) references borrow_book(id))engine InnoDB;
